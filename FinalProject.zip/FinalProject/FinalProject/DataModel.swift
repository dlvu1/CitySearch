//
//  DataModel.swift
//  FinalProject
//
//  Created by Duyen Vu on 3/16/24.
//

import Foundation
import SwiftData

struct DataModel {
    var cities: [CityModel]
}
