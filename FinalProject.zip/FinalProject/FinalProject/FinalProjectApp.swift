//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by Duyen Vu on 3/16/24.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
